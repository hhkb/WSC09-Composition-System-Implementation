WSC 09 Solution Checker:
/test/org/sigoa/wsc/c2009/parser/Tester.java