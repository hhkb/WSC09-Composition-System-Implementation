Web Service Challenge 2008 Testset Generator

Please note: At least 500MB should be allocated for the solution generator!

Please start the GUI with the VM parameters:
-Xms1024m
-Xmx1024m
Example:
java -Xms1024m -Xmx1024m -jar ChallengeSoftware.jar

Distributed Systems Group
University of Kassel
Created by Marc Kirchhoff, Thomas Weise and Steffen Bleul 
Contact&Questions: bleul@vs.uni-kassel.de
Homepage: http://www.vs.uni-kassel.de/