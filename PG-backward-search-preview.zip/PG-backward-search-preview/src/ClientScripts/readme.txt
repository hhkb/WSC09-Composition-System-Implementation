Contents:
---------

Ant files for automatic building of WebService Interfaces.

ClientCallbackWSInterfaceBuild.xml

Building the WSDL file and server stubs for the client callback interface.

CompositionSystemWSInterfaceBuild.xml

Building the WSDL file for the WSC competition service composition system.