Contents:
---------

The Client UI:
/de/vs/unikassel/query/client/gui/WSCClient.java

The required composition system interfaces!

Client Callback WSDL:
/de/vs/unikassel/query/client/callback_interface/ClientCallbackInterfaceService.wsdl

Server Composition System WSDL:
/de/vs/unikassel/query/server/CompositionSystemInterfaceService.wsdl

Composition System Example Implementation:
/de/vs/unikassel/query/server/CompositionSystemImpl.java

This example implementation is NOT a composition system. The system sends a fixed bpel solution file.